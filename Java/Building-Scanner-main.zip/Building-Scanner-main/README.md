# Project 1: Building a Scanner
## Created by Riley Moore, Jacob Bartlett, and Sam Wilson

### Introduction: 
  This Scanner is used to take an input (file containing a program) and output the tokens from the given input. The tokens that will be produced are based on the contents of     the input file. The tokens must follow the production rules for the language written in our scanner, otherwise the output will return an error. This scanner is written in and   based in Java.
  The Parser will use the original scanner to take in a file and scan it, then parse and separate the individually, outputting them in HTML style syntax. 

### Installation:
  To run this project, compile "javac scanner.java" and then type "java scanner.java textFileName".
  
### Acknowledgements: 
  For the structure of the scanner and the parser, we referenced chapter 2 in "Programming Language Pragmatics" by Morgan Kaufmann.
  
  Scott, M. L. (2016). 2 Programming Language Syntax. In Programming language pragmatics. essay, Morgan Kaufmann. 
